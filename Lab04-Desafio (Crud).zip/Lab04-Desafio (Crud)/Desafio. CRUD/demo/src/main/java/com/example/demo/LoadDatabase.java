/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
class LoadDatabase {

  private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

  @Bean
  CommandLineRunner initDatabase(EmployeeRepository repository) {

    return args -> {
      log.info("Preloading " + repository.save(new Employee("Hélder", "Engenheiro")));
      log.info("Preloading " + repository.save(new Employee("Wami", "Engenheiro")));
      log.info("Preloading " + repository.save(new Employee("Pascoal", "Arquitetura")));
      log.info("Preloading " + repository.save(new Employee("Da Silva", "Gestor")));
      log.info("Preloading " + repository.save(new Employee("Bilbo ", "burglar")));
      log.info("Preloading " + repository.save(new Employee("Frodo", "thief")));
    };
  }
}
